package project;
import java.util.*;

public class MainMethod {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Player.hardCoded();
        int choice;

        do {
            System.out.println("\n\n1. Add Player\n2. Display Data\n3. Search Player\n4. Update Data\n5. Delete \n6. Exit\n");
            System.out.println("Enter the choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    Player.addData();
                    break;
                case 2:
                    Player.display();
                    break;
                case 3:
                    Player.search();
                    break;
                case 4:
                    Player.updatePlayer();
                    break;
                case 5:
                    Player.removePlayer();
                    break;
                case 6:
                    System.out.println("Exit");
                    break;
                default:
                    System.out.println("Invalid Choice!");
                    break;
            }
        } while (choice != 6);

        sc.close(); 
    }
}
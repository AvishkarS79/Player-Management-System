package project;

import java.util.*;

public class Player {
    int jerseyNo;
    String name;
    int matches;
    int runs;
    int wickets;

    public static int count = 0;
    public static Player[] players = new Player[6];
    static Scanner sc = new Scanner(System.in);

    public Player() {
        
    }

    public Player(int jerseyNo, String name, int matches, int runs, int wickets) {
        this.jerseyNo = jerseyNo;
        this.name = name;
        this.matches = matches;
        this.runs = runs;
        this.wickets = wickets;
    }

    public int getJerseyNo() {
        return jerseyNo;
    }

    public void setJerseyNo(int jerseyNo) {
        this.jerseyNo = jerseyNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMatches() {
        return matches;
    }

    public void setMatches(int matches) {
        this.matches = matches;
    }

    public int getRuns() {
        return runs;
    }

    public void setRuns(int runs) {
        this.runs = runs;
    }

    public int getWickets() {
        return wickets;
    }

    public void setWickets(int wickets) {
        this.wickets = wickets;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Player.count = count;
    }

    public static void hardCoded() {
        players[0] = new Player(18, "Virat Kohli", 530, 35000, 13);
        players[1] = new Player(45, "Rohit Sharma", 480, 26000, 27);
        players[2] = new Player(8, "R Jadeja", 400, 4000, 400);
        players[3] = new Player(33, "Hardik Pandya", 234, 6500, 250);
        players[4] = new Player( 7, "MS Dhoni", 700, 7000, 7);
        
       
        count = 5;
    }

    public static void addData() {
        System.out.println("Enter the Number of Players You Want to Add : ");
        int n = sc.nextInt();

        if (count + n > players.length) {
            System.out.println("Not enough space to add new players.");
            return;
        }

        for (int i = 0; i < n; i++) {
            System.out.println("Enter the jersey number: ");
            int jerseyNo = sc.nextInt();
            System.out.println("Enter the name of the player: ");
            String name = sc.next();
            System.out.println("Enter the number of matches: ");
            int matches = sc.nextInt();
            System.out.println("Enter the runs of the player: ");
            int runs = sc.nextInt();
            System.out.println("Enter the wickets: ");
            int wickets = sc.nextInt();
            players[count] = new Player(jerseyNo, name, matches, runs, wickets);
            count++;
        }
    }

    public static void display() {
        System.out.println("\nJersey No\tName\tMatches\tRuns\tWickets\n");
        for (int i = 0; i < count; i++) {
            Player player = players[i];
            System.out.println(player.jerseyNo + "\t\t" + player.name + "\t" + player.matches + "\t" + player.runs + "\t" + player.wickets);
        }
    }

    public static void search() {
        System.out.println("1. Jersey No\n2. Player Name");
        System.out.println("Enter the choice you want to search by: ");
        int choice = sc.nextInt();

        if (choice == 1) {
            System.out.println("Enter the jersey number you want to search: ");
            int jerseyNo = sc.nextInt();
            boolean found = false;
            for (int i = 0; i < count; i++) {
                if (players[i].jerseyNo == jerseyNo) {
                    System.out.println("\nJersey No\tName\tMatches\tRuns\tWickets\n");
                    System.out.println(players[i].jerseyNo + "\t\t" + players[i].name + "\t" + players[i].matches + "\t" + players[i].runs + "\t" + players[i].wickets);
                    found = true;
                    break;
                }
            }
            if (!found) {
                System.out.println("Not found");
            }
        } else if (choice == 2) {
            System.out.println("Enter the name you want to search: ");
            String name = sc.next();
            boolean found = false;
            for (int i = 0; i < count; i++) {
                if (players[i].name.equals(name)) {
                    System.out.println("\nJersey No\tName\tMatches\tRuns\tWickets\n");
                    System.out.println(players[i].jerseyNo + "\t\t" + players[i].name + "\t" + players[i].matches + "\t" + players[i].runs + "\t" + players[i].wickets);
                    found = true;
                    break;
                }
            }
            if (!found) {
                System.out.println("Not found");
            }
        } else {
            System.out.println("You entered the wrong choice");
        }
    }

    public static void removePlayer() {
        System.out.println("Delete by \n1. Jersey No\n2. Name");
        int choice = sc.nextInt();
        if (choice == 1) {
            System.out.println("Enter the jersey number: ");
            int jerseyNo = sc.nextInt();
            boolean found = false;
            for (int i = 0; i < count; i++) {
                if (players[i].jerseyNo == jerseyNo) {
                    for (int j = i; j < count - 1; j++) {
                        players[j] = players[j + 1];
                    }
                    players[count - 1] = null;
                    count--;
                    found = true;
                    break;
                }
            }
            if (!found) {
                System.out.println("Player with the given jersey number not found");
            }
        } else if (choice == 2) {
            System.out.println("Enter the player name you want to remove: ");
            String name = sc.next();
            boolean found = false;
            for (int i = 0; i < count; i++) {
                if (players[i].name.equals(name)) {
                    for (int j = i; j < count - 1; j++) {
                        players[j] = players[j + 1];
                    }
                    players[count - 1] = null;
                    count--;
                    found = true;
                    break;
                }
            }
            if (!found) {
                System.out.println("Player with the given name not found");
            }
        } else {
            System.out.println("Invalid choice");
        }
    }

    public static void updatePlayer() {
        System.out.println("Update by \n1. Jersey No\n2. Name");
        int choice = sc.nextInt();
        if (choice == 1) {
            System.out.println("Enter the jersey number: ");
            int jerseyNo = sc.nextInt();
            boolean found = false;
            for (int i = 0; i < count; i++) {
                if (players[i].jerseyNo == jerseyNo) {
                    System.out.println("Enter new name: ");
                    players[i].setName(sc.next());
                    System.out.println("Enter new number of matches: ");
                    players[i].setMatches(sc.nextInt());
                    System.out.println("Enter new runs: ");
                    players[i].setRuns(sc.nextInt());
                    System.out.println("Enter new wickets: ");
                    players[i].setWickets(sc.nextInt());
                    found = true;
                    break;
                }
            }
            if (!found) {
                System.out.println("Player with the given jersey number not found");
            }
        } else if (choice == 2) {
            System.out.println("Enter the player name you want to update: ");
            String name = sc.next();
            boolean found = false;
            for (int i = 0; i < count; i++) {
                if (players[i].name.equals(name)) {
                    System.out.println("Enter new jersey number: ");
                    players[i].setJerseyNo(sc.nextInt());
                    System.out.println("Enter new number of matches: ");
                    players[i].setMatches(sc.nextInt());
                    System.out.println("Enter new runs: ");
                    players[i].setRuns(sc.nextInt());
                    System.out.println("Enter new wickets: ");
                    players[i].setWickets(sc.nextInt());
                    found = true;
                    break;
                }
            }
            if (!found) {
                System.out.println("Player with the given name not found");
            }
        } else {
            System.out.println("Invalid choice");
        }
    }
}
